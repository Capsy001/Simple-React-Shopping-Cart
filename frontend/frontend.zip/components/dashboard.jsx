import React from "react";
import { Component } from "react";
import { login } from "../restcall";
import "./login.css";

export default class Dashboard extends Component
{
    constructor()
    {
      super();
  }
  
  handleLogout =(event) =>
  {
    sessionStorage.setItem('logged', 'false');

    sessionStorage.setItem("loggedName", "NotLogged!");
    sessionStorage.setItem("loggedEmail", "NotLogged!");
    sessionStorage.setItem("loggedRole", "NotLogged!");

    sessionStorage.clear;
    window.location.href = "/";
  }

  componentWillMount()
  {
    const logged = sessionStorage.getItem('logged');

    if (logged == "false")
    {
      alert("User not logged in!");
      window.location.href = "/";
    }
  }

    render()
    {
        return (
          <div className="loginForm">
            <h2>Dashboard</h2>
            <button onClick={this.handleLogout}>Logout</button>
            <hr></hr>
            <h2>Hi {sessionStorage.getItem("loggedName")}</h2>
            <table>
              <tr>
                <th>Name</th>
                <td>{sessionStorage.getItem("loggedName")}</td>
              </tr>
              <tr>
                <th>Email</th>
                <td>{sessionStorage.getItem("loggedEmail")}</td>
              </tr>
              <tr>
                <th>Role</th>
                <td>{sessionStorage.getItem("loggedRole")}</td>
              </tr>
            </table>
          </div>
        );
    }

}