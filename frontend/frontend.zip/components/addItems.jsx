import React from "react";
import { Component } from "react";

export default class AddItem extends Component
{
    constructor()
    {
        super();
    }


    render()
    {
        return (
          <div>
            <form>
              <div>
                <label>Item Name</label>
                <input type="text" onChange={handleItemName}></input>
              </div>
              <div>
                <label>Item Price</label>
                <input type="number" onChange={handleItemPrice}></input>
              </div>
              <div>
                <label>Description</label>
                <input type="text" onChange={handleItemName}></input>
              </div>
            </form>
          </div>
        );
    }
}